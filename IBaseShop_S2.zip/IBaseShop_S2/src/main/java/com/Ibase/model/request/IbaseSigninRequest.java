package com.Ibase.model.request;

import javax.validation.constraints.NotBlank;

public class IbaseSigninRequest {
	@NotBlank
	private String userName;

	@NotBlank
	private String password;
	
	

	public String getUsername() {
		return userName;
	}

	public void setUsername(String username) {
		this.userName = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
