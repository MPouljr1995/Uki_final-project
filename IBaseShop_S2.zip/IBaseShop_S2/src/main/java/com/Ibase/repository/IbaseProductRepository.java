package com.Ibase.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.Ibase.model.IbaseProduct;

@Repository
public interface IbaseProductRepository extends MongoRepository<IbaseProduct, String> {
	
	List<IbaseProduct> findByShopId(String shopId);

	List<IbaseProduct> findByTitleContaining(String title);

	List<IbaseProduct> findBySellPriceBetween(double minPrice, double maxPrice , Sort sort);

//	List<IbaseProducts> findBySellPriceGreaterThan(double minPrice);
	
}
