package com.Ibase.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Ibase.model.IbaseProduct;
import com.Ibase.repository.IbaseProductRepository;

@Service
public class IbaseProductService {
	@Autowired
	IbaseProductRepository ibaseProductRepository;

	public ResponseEntity<List<IbaseProduct>>getAllProducts() {
		try {
			return new ResponseEntity<>(ibaseProductRepository.findAll(),HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);	
		}
	}

	public ResponseEntity<IbaseProduct> createProduct(IbaseProduct product) {
		try {
			return new ResponseEntity<>(ibaseProductRepository.insert(product),HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	public ResponseEntity<Optional<IbaseProduct>> getProductById(String productId) {
		Optional<IbaseProduct> product = ibaseProductRepository.findById(productId);
		try {
			if (product.isPresent()) {
				return new ResponseEntity<>(product,HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);	
		}	
	}

	public ResponseEntity<String> deleteProductById(String productId) {
		Optional<IbaseProduct> product = ibaseProductRepository.findById(productId);
		try {
			if (product.isPresent()) {
				ibaseProductRepository.deleteById(productId);
				return new ResponseEntity<>("PRODUCT DELETED",HttpStatus.OK);
			} else {
				return new ResponseEntity<>("PRODUCT NOT FOUND",HttpStatus.NOT_FOUND);
			}	
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);	
		}
	}

	public ResponseEntity<IbaseProduct> updateProductById(IbaseProduct updateProduct, String productId) {
		Optional<IbaseProduct> oldProduct = ibaseProductRepository.findById(productId);
		try {
			if(oldProduct.isPresent()) {
				IbaseProduct _product = oldProduct.get();
				_product.setTitle(updateProduct.getTitle());
				_product.setDescription(updateProduct.getDescription());
				_product.setLastPrice(updateProduct.getLastPrice());
				_product.setSellPrice(updateProduct.getSellPrice());
				_product.setWarranty(updateProduct.getWarranty());
				_product.setRating(updateProduct.getRating());
				_product.setStock(updateProduct.getStock());
				_product.setBrand(updateProduct.getBrand());
				_product.setModel(updateProduct.getModel());
				
				return new ResponseEntity<>(ibaseProductRepository.save(_product),HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);	
		}	
	}

	public ResponseEntity<List<IbaseProduct>> getProductByShopId(String shopId) {
		List<IbaseProduct> shopProducts = ibaseProductRepository.findByShopId(shopId);
		try {
			if(shopProducts.isEmpty()) {
					return new ResponseEntity<>( HttpStatus.NO_CONTENT);
				} else {
					return new ResponseEntity<>(shopProducts ,HttpStatus.OK);
				}
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<List<IbaseProduct>> getProductByTitle(String title) {
		List<IbaseProduct> product = ibaseProductRepository.findByTitleContaining(title);
		try {
			if (product.isEmpty()) {
				return new ResponseEntity<>( HttpStatus.NO_CONTENT);
			} else {
				return new ResponseEntity<>(product ,HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

//	public List<IbaseProducts> getProductByPrice(double minPrice) {
//		return ibaseProductsRepository.findBySellPriceGreaterThan(minPrice);
//	}

	public ResponseEntity<List<IbaseProduct>> getProductByPriceBB(double minPrice, double maxPrice) {
		Sort sort = Sort.by(Sort.Direction.DESC,"sellPrice");
		List<IbaseProduct> product = ibaseProductRepository.findBySellPriceBetween(minPrice, maxPrice, sort);
		try {
			if (product.isEmpty()) {
				return new ResponseEntity<>( HttpStatus.NO_CONTENT);
			} else {
				return new ResponseEntity<>(product ,HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
